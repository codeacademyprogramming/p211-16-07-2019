﻿using System;
using System.Net.Mail;

namespace P211_ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(CompareAirConditioners<IAirConditionable>(new BMW(), new Audi()));
        }

        static bool CompareAirConditioners<T>(T car1, T car2) where T : IAirConditionable //generic methods
        {
            return car1.AirConditionerPower() > car2.AirConditionerPower();
        }
    }

    interface IAirConditionable
    {
        int AirConditionerPower();
    }

    class VAZ : Car { }

    class BMW : Car, IAirConditionable
    {
        public int AirConditionerPower() => 10;
    }

    class Audi : Car, IAirConditionable
    {
        public int AirConditionerPower() => 20;
    }

    class Car
    {
        public string MarkaName { get; set; }
        public string ModelName { get; set; }
        public float Volume { get; set; }

        public void Go() { }
        public void Brake() { }
    }


    class ItemList<T> where T : class, Idable  //generic types constraints
    {
        private T[] items;
        private int activeIndex = 0;

        public ItemList(int listLength)
        {
            items = new T[listLength];
        }

        public void AddItem(T item)
        {
            if (activeIndex < items.Length)
            {
                items[activeIndex++] = item;
            }
        }

        public T FindItemById(int id)
        {
            foreach (T item in items)
            {
                if (item.Id == id)
                {
                    return item;
                }
            }

            return null;
        }
    }

    #region GroupList
    //class GroupList
    //{
    //    private Group[] groups;
    //    private int activeIndex = 0;

    //    public GroupList(int groupCount)
    //    {
    //        groups = new Group[groupCount];
    //    }

    //    public void AddGroup(Group group)
    //    {
    //        if(activeIndex < groups.Length)
    //        {
    //            groups[activeIndex] = group;
    //        }
    //    }

    //    public Group FindGroupById(int groupId)
    //    {
    //        foreach (Group gr in groups)
    //        {
    //            if(gr.Id == groupId)
    //            {
    //                return gr;
    //            }
    //        }

    //        return null;
    //    }
    //}
    #endregion

    #region StudentList
    //class StudentList
    //{
    //    private Student[] students;
    //    private int activeIndex = 0;

    //    public StudentList(int listLength)
    //    {
    //        students = new Student[listLength];
    //    }

    //    public void AddStudent(Student newStudent)
    //    {
    //        if(activeIndex < students.Length)
    //        {
    //            students[activeIndex++] = newStudent;
    //        }
    //    }

    //    public Student FindStudentById(int id)
    //    {
    //        foreach (Student stu in students)
    //        {
    //            if (stu.Id == id)
    //            {
    //                return stu;
    //            }
    //        }

    //        return null;
    //    }
    //}
    #endregion

    interface Idable
    {
        int Id { get; set; }
    }

    class Student
    {
        private static int _id;
        public int Id { get; private set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        private string _email;

        static Student()
        {
            _id = 1000;
        }

        public string Email
        {
            get { return _email; }
            set
            {
                try
                {
                    MailAddress mailAddress = new MailAddress(value);
                    _email = value;
                }
                catch
                {
                    throw new ArgumentException("Email address is not valid");
                }
            }
        }

        public Student()
        {
            Id = _id++;
        }
    }

    class Group : Idable
    {
        private static int _id = 1;
        public int Id { get; set; }
        public string Name { get; set; }

        public Group()
        {
            Id = _id++;
        }
    }

    class Snake : Idable
    {
        public Snake()
        {

        }
        public Snake(char a)
        {

        }

        public int Id { get; set; }
        public string Name { get; set; }
    }

    class Human { }
    class Woman : Human { }
    class Man : Human { }
}
